-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 21 oct. 2020 à 09:45
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `SIMPLON`
--

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `id` int(11) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `telephone` int(8) NOT NULL,
  `image` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`id`, `mot_de_passe`, `email`, `nom`, `telephone`, `image`, `genre`, `date`) VALUES
(1, '202cb962ac59075b964b07152d234b70', 'ami@gmail.com ', 'ami', 58586214, 'ajaximg.png', 'Masculin', '2020-10-13'),
(2, '81dc9bdb52d04dc20036dbd8313ed055', 'aya@gmail.com ', 'aya', 55848548, 'Juste pour vous !.png', 'Masculin', '2020-10-13'),
(3, 'c20ad4d76fe97759aa27a0c99bff6710', 'hamid@gmail.com ', 'hamid', 58587854, 'Juste pour vous ! (1).png', 'Masculin', '2020-10-13'),
(4, '202cb962ac59075b964b07152d234b70', 'amoi@gmail.com ', 'amo', 458548, 'Juste pour vous ! (1).png', 'Masculin', '2020-10-15'),
(5, '202cb962ac59075b964b07152d234b70', 'diallo@gmail.com ', 'diallo', 5214536, 'Juste pour vous ! (4) (copie).png', 'Masculin', '2020-10-15'),
(6, '123', 'ayao@gmail.com ', 'aya', 55645410, 'Juste pour vous ! (2) (1).png', 'Feminin', '2020-10-15'),
(7, '202cb962ac59075b964b07152d234b70', 'amil@gmail.com ', 'amil', 55645410, 'Juste pour vous ! (2) (1).png', 'Feminin', '2020-10-15'),
(8, 'ab4f63f9ac65152575886860dde480a1', 'jbamba060@gmail.com ', 'nasco', 54212365, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Masculin', '2020-10-15'),
(9, 'ab4f63f9ac65152575886860dde480a1', 'jbamkiba060@gmail.com ', 'nasco', 542123655, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Feminin', '2020-10-15'),
(10, '202cb962ac59075b964b07152d234b70', 'bigue@gmail.com ', 'bigue', 54212365, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Masculin', '2020-10-15'),
(11, '202cb962ac59075b964b07152d234b70', 'diaw@gmail.com ', 'diaw', 445454, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Feminin', '2020-10-15'),
(12, '202cb962ac59075b964b07152d234b70', 'diallo2@gmail.com ', 'diallo2', 45415, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Masculin', '2020-10-15'),
(13, '202cb962ac59075b964b07152d234b70', 'mariam@gmail.com', 'mariam', 54212365, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Feminin', '2020-10-15'),
(14, '202cb962ac59075b964b07152d234b70', 'apo@gmail.com', 'apo', 84548456, '120027949_2754636251482034_8712225041833857109_o.jpg', 'Feminin', '2020-10-15');

-- --------------------------------------------------------

--
-- Structure de la table `presence`
--

CREATE TABLE `presence` (
  `iduser` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `datesign` date NOT NULL DEFAULT current_timestamp(),
  `timesign` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `presence`
--

INSERT INTO `presence` (`iduser`, `id`, `datesign`, `timesign`) VALUES
(1, 11, '2020-10-15', '2020-10-15 12:15:03'),
(2, 13, '2020-10-15', '2020-10-15 12:21:59'),
(3, 14, '2020-10-15', '2020-10-15 12:25:18');

-- --------------------------------------------------------

--
-- Structure de la table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `teacher`
--

INSERT INTO `teacher` (`id`, `nom`, `email`, `mot_de_passe`) VALUES
(1, 'nasco', 'nasco@gmail.com ', '202cb962ac59075b964b07152d234b70'),
(2, 'ami', 'ami@gmail.com ', '202cb962ac59075b964b07152d234b70'),
(3, 'apo', 'ap ', 'd41d8cd98f00b204e9800998ecf8427e'),
(4, 'nasco', 'apo@gmail.com ', '202cb962ac59075b964b07152d234b70'),
(5, 'awa', 'awa@gmail.com ', '202cb962ac59075b964b07152d234b70'),
(6, 'bigué', 'bigue@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `presence`
--
ALTER TABLE `presence`
  ADD PRIMARY KEY (`iduser`);

--
-- Index pour la table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `etudiant`
--
ALTER TABLE `etudiant`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `presence`
--
ALTER TABLE `presence`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
