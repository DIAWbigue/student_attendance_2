<?php
//Chargement du fichier de connexion à la base de donnee
include("basededonne.php");

//Préparation de la liste des variables
$nom = addslashes($_POST['nom']);
$email = addslashes($_POST['email']);
$motdepasse = md5($_POST['motdepasse']);

//Preparation de la requete de verification
$requete = "SELECT * FROM teacher WHERE email='".$email."'";
$statement = $conn->query($requete);
$row_count = $statement->num_rows;

// Execution de la condition de l'existance du compte.
if ($row_count >= 1) {
  echo "Vous etes deja inscrit";
}
else {
$insUser = "INSERT INTO teacher(nom, email, mot_de_passe ) VALUES('$nom', '$email', '$motdepasse')";
//Execution de la requete
if ($conn->query($insUser) === TRUE) {
  echo "<script language = 'javascript'>";
  echo "alert('Félicitations !! vous etes inscrit') ";
  echo "</script>";
}
else {
  echo "Erreur :" . $insUser . "<br>" . $conn->error;
}
}



 ?>
