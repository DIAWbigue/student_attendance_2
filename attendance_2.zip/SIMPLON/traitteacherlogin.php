<?php
// Start the session 
session_start();
//Chargement du fichier de connexion à la base de donnee
include("basededonne.php");

$email = addslashes($_POST['email']);
$motdepasse = md5($_POST['motdepasse']);

//Preparation de la requete de verification
$requete = "SELECT * FROM teacher WHERE email='" . $email . "' AND mot_de_passe ='" . $motdepasse . "'";
$statement = $conn->query($requete);
$row_count = $statement->num_rows;

// Execution de la condition de l'existance du compte.
if ($row_count >= 1) {
  $row = $statement->fetch_assoc();
  $_SESSION["idteacher"] = $row["id"];
  echo 'success';
} else {
  echo 'echec';
}
