<?php

include("basededonne.php");

$search = $_POST['date_search'];
$sql = "SELECT * FROM presence  WHERE datesign = '$search'";
$result = $conn->query($sql);
echo '<table class="table  table-hover table-responsive table-ligth" id="result">
      <thead>

          <tr>
              <th>N°</th>
              <th>Nom</th>
              <th>Email</th>
              <th>Téléphone</th>
              <th>Genre</th>
              <th>Signature</th>
          </tr>

      </thead>';
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id = $row['id'];
        $sql = "SELECT id, nom, email, telephone, genre FROM etudiant  WHERE id = '$id'";
        $resultat = $conn->query($sql);
        $etudiant = $resultat->fetch_assoc();
        echo '<tbody>
       <tr>
         <td>' . $etudiant['id'] .
            '</td>
         <td>' . $etudiant['nom'] .

            '</td>
         <td>' . $etudiant['email'] .

            '</td>
         <td>' . $etudiant['telephone'] .

            '</td>
         <td>' . $etudiant['genre'] .

            '</td>
         <td>' . $row['timesign'] .

            '</td>
       </tr>
     </tbody>';
    }
} else {
    echo '<td colspan="7" class="text-center font-italic">aucun etudiant n\'a signé à cette date</td>';
}
echo "</table>";
