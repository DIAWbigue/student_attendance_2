<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="acceil.css" />
  <title>Document</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <div class="right-column text-center">
          <p class="info">Student attendance</p>
          <form enctype="multipart/form-data" id="form">
            <div class="form-group">
              <input type="text" name="nom" id="nom" class="form-control" placeholder="Nom" required />
            </div>
            <div class="form-group">
              <input type="email" name="email" id="email" class="form-control" placeholder="Email" required />
            </div>
            <div class="form-group">
              <input type="tel" name="telephone" id="telephone" class="form-control" maxlength="8" minlength="8" placeholder="Numéro" required />
            </div>
            <div class="form-group">
              <input type="password" name="motdepasse" id="motdepasse" class="form-control" placeholder="Mot de passe" required />
            </div>
            <div class="form-group">
              <input type="password" name="confmotdepasse" id="confmotdepasse" class="form-control" placeholder="Confirmer mot de passe" required />
            </div>
            <div class="form-group">
              <input type='radio' name='genre' id="feminin" value='Feminin'> Féminin
              <input type='radio' name='genre' id="masculin" value='Masculin' checked> Masculin <br>
              <input type="hidden" name="monimage" id="monimage" value="100000" />
              Envoyer votre photo <input type="file" name="monimage" />
            </div>
            <button type="submit" name="submit" value="S'enregistrer" class="btn btn-primary btn-block">S'enregistrer </button>
            <div class="result"></div>
            <p class="or">OU</p>
            <p class="connexion">
              <a href="#"><img src="fbicone.png"> connecter avec Facebook</a><br>
              <a href="#">Mot de passe oublié?</a>
            </p>
        </div>
        </form>
      </div>
      <div class="container">
        <div class="salut">
          <p>Vous n’avez pas signer ?<a href="sign.php"> Signer</a></p>
        </div>
      </div>
    </div>
  </div>
  </div>

  <script>
    $(document).ready(function() {
      $('#form').on('submit', function(e) {
        e.preventDefault();
        var form = $(this);
        console.log(form);
        var fd = new FormData(form[0]);
        fd.append("file", $('#monimage'));
        console.log(fd);
        $.ajax({
          method: 'POST',
          enctype: 'multipart/form-data',
          url: 'traitementformulaire1.php',
          contentType: false,
          processData: false,
          cache: false,
          data: fd,
          success: function(response) {
            $('.result').html(response);
            $('#form')[0].reset();
          },
        });
        // var nom = $('#nom').val();
        // var email = $('#email').val();
        // var motdepasse = $('#motdepasse').val();
        // var confmotdepasse = $('#confmotdepasse').val();
        // var telephone = $('#telephone').val();
        // //var monimage = $('#monimage').val();
        // var genre = $("input[type='radio']:checked").val();
        //
        // $.ajax
        //   ({
        //     type: "POST",
        //     url: "traitementformulaire1.php",
        //     data: { "nom": nom, "email": email, "telephone": telephone, "motdepasse": motdepasse, "confmotdepasse": confmotdepasse, "genre": genre },
        //     success: function (data) {
        //       // $('.result').html(data);
        //       // $('#form')[0].reset();
        //     }
        //   });
      });
    });
  </script>

</body>

</html>