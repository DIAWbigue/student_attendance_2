<?php
//Chargement du fichier de connexion à la base de donnee
include("basededonne.php");

//Préparation de la liste des variables
$email = addslashes($_POST['email']);
$nom = addslashes($_POST['nom']);
$telephone = ($_POST['telephone']);
$genre = ($_POST['genre']);
$motdepasse = md5($_POST['motdepasse']);
$confmotdepasse = md5($_POST['confmotdepasse']);
$monimage = $_FILES['monimage']['name'];
$imageTemp = $_FILES['monimage']['tmp_name'];
move_uploaded_file($imageTemp, "./uploads/".$monimage);
$target_dir = "uploads/";
$uploadOk = 1;
$target_file = $target_dir.basename($_FILES["monimage"]["name"]);
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if ($motdepasse === $confmotdepasse) {

	//Preparation de la requete de verification
	$requete = "SELECT * FROM etudiant WHERE email='".$email."'";
	$statement = $conn->query($requete);
	$row_count = $statement->num_rows;
	// Execution de la condition de l'existance du compte.
	if ($row_count >= 1) {
		echo "Vous etes deja inscrit";
	}
	else {
		// if (file_exists($target_file)) {
		// 	echo "Sorry, file already exists.";
		// }
		//else {
			if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
					echo "mauvais format d'image (format exigées jpg,png ou jpeg)";
					$uploadOk = 0;
			}
			else {
				if ($_FILES["monimage"]["size"] > 500000) {
					echo "La taille de votre fichier est très large !";
				}
				else {
					$insUser = "INSERT INTO etudiant(mot_de_passe, email, nom, telephone, image, genre) VALUES('$motdepasse', '$email', '$nom', '$telephone', '$monimage', '$genre')";

					//Execution de la requete
					if ($conn->query($insUser) === TRUE) {
					  echo "<script language = 'javascript'>";
					  echo "alert('Félicitations !! vous etes inscrit') ";
					  echo "</script>";
					}
					else {
					  echo "Erreur :" . $insUser . "<br>" . $conn->error;
					}
				//}
			}
		}
	}
} else {
	echo "Merci de rentrer le meme mot de passe";
} //Fin else verification mot de passe confirme
