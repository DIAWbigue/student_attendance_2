<?php
// destroy the session
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="home.css" />
  <title>Document</title>
</head>

<body>

  <div class="container">
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <h1>STUDENT ATTENDANCE</h1>
      </div>
      <div class="col-md-3"></div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <div class="taille">
          <a href="teacherlogin.php">
            <img src="teacher.png" alt="teacher dashboard">
          </a>
        </div>
      </div>
      <div class="col-md-3">
        <div class="taille">
          <a href="registration.php">
            <img src="student.png" alt="student dashboard">
          </a>
        </div>

      </div>
      <div class="col-md-3">
        <div class="taille">
          <a href="registration.php">
            <img src="login.png" alt="registration">
          </a>
        </div>
      </div>
      <div class="col-md-3">
        <div class="taille">
          <a href="sign.php">
            <img src="sign.png" alt="sign">
          </a>
        </div>
      </div>
    </div>
  </div>

</body>

</html>