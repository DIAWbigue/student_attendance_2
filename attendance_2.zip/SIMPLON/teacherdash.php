<?php
// Start the session 
session_start();
if (!isset($_SESSION["idteacher"])) {
  header("location:teacherlogin.php");
}
?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<link rel="stylesheet" type="text/css" href="teacherdash.css" />

<body>

  <?php
  include("basededonne.php");

  $sql = "SELECT * FROM etudiant";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {

  ?>
    <div class="container">
      <div class="d-flex">
        <h2>Student List</h2>
        <button type="submit" class="btn btn-default mb-3 mt-2 ml-auto"><a href="index.php">Se déconnecter</a></button>
      </div>
      <div class="mb-3 d-flex">
        <input class="form-control mr-2" type="date" placeholder="Search" aria-label="Search" id="search">
        <button id="submit" name="submit" value="Search" class="btn btn-primary">Search </button>
      </div>
      <table class="table table-striped table-hover" id="result">
        <thead>

          <tr>
            <th>N°</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Genre</th>
            <th>Date insc</th>
          </tr>

        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
              <td> <?php echo ($row['id']) ?> </td>
              <td> <?php echo ($row['nom']) ?> </td>
              <td> <?php echo ($row['email']) ?></td>
              <td> <?php echo ($row['telephone']) ?></td>
              <td> <?php echo ($row['genre']) ?></td>
              <td> <?php echo ($row['date']) ?></td>
            </tr>
        <?php }
        }

        $conn->close(); ?>
        </tbody>
      </table>
    </div>
    <script type="text/javascript">
      $(document).ready(function() {
        $('#submit').click(function() {
          var search = $('#search').val();
          console.log(search);
          if (search !== "") {
            $.post("search.php", {
              date_search: search
            }, function(data) {
              $("#result").html(data);
            });
          }
        });

      });
    </script>
</body>

</html>